dig = input("Enter digit: ")
numb_a = int(dig + dig)
numb_b = int(dig + dig + dig)
total = int(dig) + numb_a + numb_b
print(total)
